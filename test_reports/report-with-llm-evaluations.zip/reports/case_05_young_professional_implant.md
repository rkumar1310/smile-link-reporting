# Young professional seeking implant for single back tooth, good health, premium budget

**Case ID:** case_05_young_professional_implant
**Session:** test-case-005
**Generated:** 2026-01-13T18:33:36.595Z

## Pipeline Metadata

| Field | Value |
|-------|-------|
| Scenario | VALIDATION_ERROR |
| Tone Profile | TP-01 |
| Confidence | FALLBACK |
| Outcome | BLOCK |
| Success | false |

## Driver State


## Report Not Generated

**Reason:** Input validation failed: Q3: Expected array for multi-select question "What bothers you most about teeth", received string; Q4: Expected array for multi-select question "Previous treatments", received string; Q6d: Expected array for multi-select question "Health of aesthetic teeth", received string; Q8: Invalid value for "Natural result importance"; Q12: Invalid value for "Timeline"; Q15: Invalid value for "Oral hygiene"

### Validation Errors
- Expected array for multi-select question "What bothers you most about teeth", received string
- Expected array for multi-select question "Previous treatments", received string
- Expected array for multi-select question "Health of aesthetic teeth", received string
- Invalid value for "Natural result importance"
- Invalid value for "Timeline"
- Invalid value for "Oral hygiene"
