# Urgent case with pain, multiple adjacent missing teeth, severe anxiety, economy budget

**Case ID:** case_02_urgent_pain_multiple_teeth
**Session:** test-case-002
**Generated:** 2026-01-13T18:33:36.593Z

## Pipeline Metadata

| Field | Value |
|-------|-------|
| Scenario | VALIDATION_ERROR |
| Tone Profile | TP-01 |
| Confidence | FALLBACK |
| Outcome | BLOCK |
| Success | false |

## Driver State


## Report Not Generated

**Reason:** Input validation failed: Q3: Expected array for multi-select question "What bothers you most about teeth", received string; Q4: Expected array for multi-select question "Previous treatments", received string

### Validation Errors
- Expected array for multi-select question "What bothers you most about teeth", received string
- Expected array for multi-select question "Previous treatments", received string
