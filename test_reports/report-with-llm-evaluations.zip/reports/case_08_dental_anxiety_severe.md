# Patient with severe dental anxiety, needs empathic approach

**Case ID:** case_08_dental_anxiety_severe
**Session:** test-case-008
**Generated:** 2026-01-13T18:32:56.980Z

## Pipeline Metadata

| Field | Value |
|-------|-------|
| Scenario | VALIDATION_ERROR |
| Tone Profile | TP-01 |
| Confidence | FALLBACK |
| Outcome | BLOCK |
| Success | false |

## Driver State


## Report Not Generated

**Reason:** Input validation failed: Q3: Expected array for multi-select question "What bothers you most about teeth", received string; Q4: Expected array for multi-select question "Previous treatments", received string; Q8: Invalid value for "Natural result importance"; Q11: Invalid value for "Specialist willingness"; Q12: Invalid value for "Timeline"

### Validation Errors
- Expected array for multi-select question "What bothers you most about teeth", received string
- Expected array for multi-select question "Previous treatments", received string
- Invalid value for "Natural result importance"
- Invalid value for "Specialist willingness"
- Invalid value for "Timeline"
